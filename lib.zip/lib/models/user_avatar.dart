class UserAvatar {
  final String large;
  final String medium;
  final String thumbnail;

  UserAvatar({
    required this.large,
    required this.medium,
    required this.thumbnail,
  });
}
